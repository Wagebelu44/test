<h1 align="center">💎TMB {TikTok Mass Botting}</h1>

<p align='center'>
  <b>Star ⭐ if you want more</b><br>
</p>


## Features
```js
  * View botting
  * Share botting (not patched you can do a ton of share)
  * Easy to use, Fast
  * Compatible Linux / Win / (didnt tested for macos)
  * Proxy Scrapper integrated
```

## Installation
```
  * pip install requests pystyle
```

##  Usage:
```
  * put proxy in Proxies.txt file
  * python <ShareBot.py or ViewBot.py>
  * paste video url
  * choose amount
  * enter proxy type you put in Proxies.txt
  * enter proxy timeout | choose 3 if you want a good timeout
  * enter thread | more thread = faster but make your computer slower | choose 100~1000
```

## Tricks
```js
  * Use on vps (Faster !)
  * Run 3 times one with http proxy type, one with socks4 proxy type and same for socks5
```

## Scammers
```js
  * yezzjoestar#0001 / 923211134901841982 | Selling tool for 20E
```

##  Credits:

 > Xin1337 / Wizz1337 :<br>
[![](https://cdn.discordapp.com/avatars/911603930092429354/80ffdb76af6871d09a1f068865ac7589.webp?size=40)](https://github.com/laynodev)  <br>BTC : bc1q7qetejfa3q8ukkqcn3ct9fctcah34q2rlvvnl4
<br>telegram : xin1337w
