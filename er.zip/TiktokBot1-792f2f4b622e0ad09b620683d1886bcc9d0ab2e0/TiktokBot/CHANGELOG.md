## ChangeLog 04/04/22
```c
  * Fixed amount not egal to entered amount
  * Removed Proxy for Share Proxy (Fastest now)
```

## ChangeLog 03/04/22
```c
  * Divized to to python file
  * ShareBot is not patched so you can make a lot of share
  * Added List.py
  * Added more device type (apple products)
  * Added a little advanced debug for Share bot
```

## ChangeLog 02/04/22
```c
  * Added Proxy Scrapper
  * Moved Files to ./Data/
  * Fixed Proxies.txt not found for linux
```

## ChangeLog 29/03/22
```c
  * Fixed UserAgent Errors
  * Fixed 'title: not found' for linux users
```

##  Credits:

 > Xin1337 / Wizz1337 :<br>
[![](https://cdn.discordapp.com/avatars/911603930092429354/80ffdb76af6871d09a1f068865ac7589.webp?size=40)](https://github.com/laynodev)  <br>BTC : bc1q7qetejfa3q8ukkqcn3ct9fctcah34q2rlvvnl4
<br>telegram : xin1337w
